 /**
 * gets the file input and stores car data
 * 
 *Section <your section> 
 *
 *@author <Donovan McCall> 
 *@since <10/23/23>
 *  
 *  
 */

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Prog01_aOrderedList {

	static aOrderedList aOrderedListObject;
	
	public static void main(String[] args) throws FileNotFoundException {
		
		aOrderedListObject = new aOrderedList();
		Scanner input = getFileName("Y");
		readInputFile(input);
		PrintWriter pw = getOutputFileName("Y");
		printOutputFile(pw);
		
		
	}
	
	public static Scanner getFileName(String userPrompt) throws FileNotFoundException {
		
		Scanner scan = new Scanner(System.in);
		File inputFile;
		String fileName;
		String response;
		File iFile = new File("cars.txt");
		if (userPrompt.equals("Y")) {
			System.out.println("Enter input filename");
			fileName = scan.next();
			inputFile = new File(fileName);
			if (!inputFile.exists()) {
				System.out.println("File specified '" + fileName + "' does not exist. Would you like to continue? <Y/N>");
				response = scan.next();
				getFileName(response);
			} else {
				scan = new Scanner(inputFile);
				return scan;
			}
		} else
			throw new FileNotFoundException();
		return null;
		
	}
	
	public static PrintWriter getOutputFileName(String userPrompt) throws FileNotFoundException {
		
		Scanner scan = new Scanner(System.in);
		File outputFile;
		String fileName;
		String response;
		PrintWriter pw;
		if (userPrompt.equals("Y")) {
			System.out.println("Enter output file name");
			fileName = scan.next();
			outputFile = new File(fileName);
			if (!outputFile.exists()) {
				System.out.println("File specified" + fileName + "does not exist. Would you like to continue? <Y/N>");
				response = scan.next();
				getOutputFileName(response);
			} else {
				pw = new PrintWriter(new File(fileName));
				return pw;
			}
		} else
			throw new FileNotFoundException();
		return null;
	}
	
	public static void readInputFile(Scanner sc) throws FileNotFoundException {
		
		sc = sc.useDelimiter("\\,");
		String operation, make;
		int year, price, index;
		operation = sc.next();
		do {
			if (operation.equals('A')) {
				make = sc.next();
				year = sc.nextInt();
				price = sc.nextInt();
				Car newCar = new Car(make, year, price);
				aOrderedListObject.add(newCar);
				sc.nextLine();
			}
			if (operation.equals("D")) {
				index = sc.nextInt();
				aOrderedListObject.remove(index);
			}
		} while (sc.hasNextLine());
	}
	
	public static void printOutputFile(PrintWriter pw) {
		
		pw.print("Number of cars: " + aOrderedListObject.size());
		pw.println();
		for (int i = 0; i < aOrderedListObject.size(); i++) {
			pw.println("MAke :" + aOrderedListObject.get(i).getMake());
			pw.println("Year :" + aOrderedListObject.get(i).getYear());
			pw.println("Price :" + aOrderedListObject.get(i).getPrice());
			pw.println();
		}
	}

}
