/**
 * holds data for car objects and compares them
 * 
 *Section <your section> 
 *
 *@author <Donovan McCall> 
 *@since <10/23/23>
 *  
 *  
 */

public class Car implements Comparable<Car> {

	private String make;
	private int year;
	private int price;
	
	public Car(String Make, int Year, int Price) {
		this.make = Make;
		this.year = Year;
		this.price = Price;
	}
	
	public String getMake() {
		return make;
	}
	
	public int getYear() {
		return year;
	}
	
	public int getPrice() {
		return price;
	}
	
	public int compareTo(Car other) {
		
		if (this.year > other.year) return 1;
		if (this.year < other.year) return -1;
		if (this.year == other.year) {
			if (this.price > other.price) return 1;
			if (this.price < other.price) return -1;
		}
		return 0;
	}
	
	public String toString() {
	
		return("Make: " + make + ", Year: " + year + ", Price: " + price + ";");
	
	}
}
