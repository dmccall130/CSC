/**
 * sorts the cars list
 * 
 *Section <your section> 
 *
 *@author <Donovan McCall> 
 *@since <10/23/23>
 *  
 *  
 */

import java.util.Arrays;

public class aOrderedList {
	
	private static final int SIZEINCREMENTS = 20;
	private Car[] oList;
	private int listSize;
	private int numObjects;
	
	public aOrderedList() {
		numObjects = 0;
		listSize = SIZEINCREMENTS;
		oList = new Car[SIZEINCREMENTS];
	}
	
	public void add(Car newCar) {
		oList[numObjects] = newCar;
		numObjects++;
		if (numObjects >= oList.length) {
			Car[] tempList = Arrays.copyOf(oList, 2 * oList.length);
			oList = tempList;
		}
		sortList();
	}
	
	public void remove(int index) {
		if (index <= numObjects) {
			for (int i = index; i < numObjects; i++) {
				oList[i] = oList[i + 1];
			}
			oList[numObjects] = null;
			numObjects--;
		}
	}
	
	public int size() {
		return numObjects;
	}
	
	public Car get(int index) {
		return oList[index];
	}
	
	public boolean isEmpty() {
		if (numObjects == 0) return true;
		return false;
	}
	
	public String toString() {
		if (oList.length > 0) {
			for (int i = 0; i < oList.length; i++) {
				
				return"[" + oList[i].toString() + "]";
			}
		}
		return "[]";
	}
	
	public void sortList() {
		for (int i = 0; i < oList.length - 1; i++) {
			for (int j = i + 1; j < oList.length; j++) {
				if (oList[i].compareTo(oList[j]) > 1) {
					Car temp_car = oList[i];
					oList[i] = oList[j];
					oList[j] = temp_car;
				}
			}
		}
	}
}
